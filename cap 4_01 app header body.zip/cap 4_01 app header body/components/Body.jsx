import React from 'react'
import Paragraph from './Paragraph'

function Body() {
  return(
    <div>
        <Paragraph />
        <Paragraph />
    </div>
  )
}
export default Body