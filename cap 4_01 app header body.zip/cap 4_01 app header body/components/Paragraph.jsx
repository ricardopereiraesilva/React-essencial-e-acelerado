import React from 'react'

function Paragraph() {
  return(
    <div>
        <p>Parágrafo</p>
    </div>
  )
}
export default Paragraph