import React from 'react'
import Header from './components/Header'
import Body from './components/Body'
import './app.css';


function App() {
  return(
    <div>
      <Header title="Criar e ativar ambiente virtual" />
      <Body text={
        ["Na pasta do projeto, abrir terminal e criar uma pasta com um nome (aqui,venv): python -m venv venv.",
        "Ativar para entrar no v_env: '. .\\venv\\Scripts\\activate' (na pasta do projeto). Aparece a pasta, mas com '(nome_do_virtualenv)' antes, o que significa estar trabalhando no v_env."]} />
    </div>
  )
}
export default App