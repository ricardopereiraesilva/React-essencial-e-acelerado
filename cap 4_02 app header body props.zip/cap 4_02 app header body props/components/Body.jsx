import React from 'react'
import Paragraph from './Paragraph'


function Body(props) {
  return(
    <div>
        <Paragraph text={props.text[0]}/>
        <Paragraph text={props.text[1]}/>
    </div>
  )
}
export default Body