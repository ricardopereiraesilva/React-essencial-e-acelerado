import React from 'react'

function Paragraph(props) {
  return(
    <div>
        <p>{props.text}</p>
    </div>
  )
}
export default Paragraph