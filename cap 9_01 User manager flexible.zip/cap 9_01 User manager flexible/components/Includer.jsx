import React, {useState} from 'react'

function Includer(props) {
    const [textInput, setTextInput] = useState('')
    const handleInputChange = (e) => {
        setTextInput(e.target.value)
    }

    function insert() {
        props.sentInsert(textInput)
        setTextInput('')
    }

    function setManaging() {
        props.sentSetManaging()
    }

    return(
        <div>
            <div className='aux'>
                <h1>Inserir nome do usuário:</h1>
                <input
                    type="text"
                    id="textInput"
                    name="textInput"
                    value={textInput}
                    onChange={handleInputChange}
                />
            </div>    
            <div className='aux'>
                <button onClick={insert}>OK</button>
                <button onClick={setManaging}>Cancelar</button>
            </div>
        </div>    
    )
}
export default Includer
