import React from 'react'

function Selector(props) {
    function setRemove() {
        props.sentSetRemove()
    }
    function setInsert() {
        props.sentSetInsert()
    }  

    return(
        <div className='button'>
            <button onClick={setRemove}> Remover Usuário</button>	
            <button onClick={setInsert}> Inserir Usuário</button>	
        </div>    
    )
}
export default Selector
