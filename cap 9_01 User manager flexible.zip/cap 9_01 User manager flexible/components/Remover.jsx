import React, {useState} from 'react'

function Remover(props) {
    const [selectedUser, setSelectedUser] = useState(null)
    const handleRadioChange = (event) => {
        setSelectedUser(event.target.value)  }

    function remove() {
        props.sentRemove(selectedUser)
        setSelectedUser(null)    }

    function setManaging() {
        props.sentSetManaging()    }

    return(
        <div>
            <div className='aux'>
                <h1>Remover usuário</h1>
            </div>    
            <div className='aux'>
                <ul>
                {props.users.map((user) => (
                    <li key={user}>
                    <input
                        type="radio"
                        name="user"
                        value={user}
                        checked={selectedUser === user}
                        onChange={handleRadioChange}
                    />
                    {user}
                    </li>
                ))}
                </ul>
            </div>    
            <div className='aux'>
                <button onClick={remove}>OK</button>
                <button onClick={setManaging}>Cancelar</button>
            </div>
        </div>
  )
}
export default Remover
