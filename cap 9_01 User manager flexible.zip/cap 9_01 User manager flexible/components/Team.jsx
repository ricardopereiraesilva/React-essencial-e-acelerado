import React from 'react'
import User from './User'

function Team(props) {
  return(
    <div className='team'>
      {props.users.map((userName, index) => (
        <User key={index} name={userName} sentEnableUser={props.sentEnableUser} />
      ))}
    </div>
  )
}
export default Team
