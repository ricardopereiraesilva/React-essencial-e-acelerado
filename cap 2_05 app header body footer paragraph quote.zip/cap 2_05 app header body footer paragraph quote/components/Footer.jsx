import React from 'react'

function Body() {
  return(
    <div>
        <p>notas</p>
    </div>
  )
}
export default Body