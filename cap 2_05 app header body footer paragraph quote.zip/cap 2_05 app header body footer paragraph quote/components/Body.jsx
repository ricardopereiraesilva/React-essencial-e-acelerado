import React from 'react'
import Paragraph from './Paragraph'
import Quote from './Quote'

function Body() {
  return(
    <div>
        <Paragraph />
        <Paragraph />
        <Quote />
        <Paragraph />
    </div>
  )
}
export default Body