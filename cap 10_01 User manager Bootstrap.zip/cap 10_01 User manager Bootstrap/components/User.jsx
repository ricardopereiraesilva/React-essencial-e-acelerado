import React from 'react'
import { Button, Container, Row, Col } from 'react-bootstrap'

function User(props) {

    function handleClick(){
        props.sentEnableUser(props.name);  
    }

    return (
        <Container 
            style={{ 
                backgroundColor: '#ADD8E6', 
                border: '2px solid #2C3E50', 
                borderRadius: '5px',
                padding: '10px',
                margin: '5px'
            }} 
            className="text-center"
        >
            <Row className="mb-3"> 
                <h5>{"Usuário: " + props.name}</h5>   
            </Row>
            <Row>
                <Col>
                    <Button variant="dark" onClick={handleClick}>Selecionar</Button>
                </Col>
            </Row>
        </Container>
    )
}

export default User

