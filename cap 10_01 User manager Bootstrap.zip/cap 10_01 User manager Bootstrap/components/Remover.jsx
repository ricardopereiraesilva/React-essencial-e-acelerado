import React, { useState } from 'react';
import { Button, Container, Row, Col, Form } from 'react-bootstrap';

function Remover(props) {
    const [selectedUser, setSelectedUser] = useState(null);

    const handleRadioChange = (event) => {
        setSelectedUser(event.target.value);
    };

    function remove() {
        props.sentRemove(selectedUser);
        setSelectedUser(null);
    }

    function setManaging() {
        props.sentSetManaging();
    }

    return (
        <Container className="text-center">
            <Row className="mb-1">
                <h2>Remover usuário</h2>
            </Row>

            <Row className="mb-3">
                <Col>
                    {props.users.map((user) => (
                        <Form.Group key={user} controlId={`user-${user}`} className="d-flex justify-content-center">
                            <Form.Check 
                                type="radio"
                                label={user}
                                name="user"
                                value={user}
                                checked={selectedUser === user}
                                onChange={handleRadioChange}
                            />
                        </Form.Group>
                    ))}
                </Col>
            </Row>

            <Row className="justify-content-center">
                <Col xs="auto">
                    <Button variant="primary" className="mr-2" onClick={remove}>OK</Button>
                    {' '}
                    <Button variant="secondary" onClick={setManaging}>Cancelar</Button>
                </Col>
            </Row>
        </Container>
    );
}

export default Remover;


