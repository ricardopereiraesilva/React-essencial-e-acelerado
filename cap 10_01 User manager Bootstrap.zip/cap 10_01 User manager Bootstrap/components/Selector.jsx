import React from 'react';
import { Button, Container } from 'react-bootstrap';

function Selector(props) {

    function setRemove() {
        props.sentSetRemove();
    }

    function setInsert() {
        props.sentSetInsert();
    }  

    return (
        <Container className="d-flex justify-content-center mt-1 mr-2">
            <Button variant="primary" className="mr-3" onClick={setInsert}>Inserir Usuário</Button>
            <div style={{ width: '16px' }}></div> {/* Espaçador */}
            <Button variant="secondary" onClick={setRemove}>Remover Usuário</Button>
        </Container>
    )
}

export default Selector;
