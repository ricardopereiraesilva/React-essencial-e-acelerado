import React, { useState } from 'react'
import { Button, Form, Container, Row, Col } from 'react-bootstrap'

function Includer(props) {
    const [textInput, setTextInput] = useState('')
    const handleInputChange = (e) => {
        setTextInput(e.target.value)
    };

    function insert() {
        props.sentInsert(textInput)
        setTextInput('')
    }

    function setManaging() {
        props.sentSetManaging()
    }

    return (
        <Container fluid className="d-flex align-items-top min-vh-100 pt-2">
            <div className="w-100">
                <Row className="justify-content-center mb-3">
                    <Col xs={6}md={5}lg={4}>
                        <h2>Inserir nome do usuário:</h2>
                    </Col>
                    <Col xs={6}md={5}lg={4}>
                        <Form.Group controlId="formTextInput" className="mb-0">
                            <Form.Control
                                type="text"
                                value={textInput}
                                onChange={handleInputChange}
                            />
                        </Form.Group>
                    </Col>
                </Row>
                <Row className="justify-content-center">
                    <Col xs="auto">
                        <Button variant="primary" onClick={insert}>OK</Button>
                        {' '}
                        <Button variant="secondary" onClick={setManaging}>Cancelar</Button>
                    </Col>
                </Row>
            </div>
        </Container>
    )
}

export default Includer