import React from 'react'
import Display from './Display'
import Selector from './Selector'
import Team from './Team'

function Manager(props) {
    return(
        <div>
            <Display message={"Usuário ativo: " + props.activeUser} />
            <Selector  sentSetRemove={props.sentSetRemove} sentSetInsert={props.sentSetInsert} />
            <Team users={props.users} sentEnableUser={props.sentEnableUser} />
        </div>    
    )
}
export default Manager