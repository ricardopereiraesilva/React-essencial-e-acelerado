import React from 'react';
import { Card } from 'react-bootstrap';

function Display(props) {
    return (
      <Card style={{ border: '2px solid #2C3E50', backgroundColor: '#f5f5f5', margin: '10px'}} className="text-center">
          <Card.Body>
              <Card.Title>{props.message}</Card.Title>
          </Card.Body>
      </Card>
    )
}

export default Display;
