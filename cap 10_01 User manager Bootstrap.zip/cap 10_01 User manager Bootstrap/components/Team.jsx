import React from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import User from './User'

function Team(props) {
    return (
        <Container style={{
            border: '2px solid #2C3E50',  // Borda cinza escuro
            backgroundColor: '#f5f5f5',  // Fundo cinza claro
            padding: '20px', 
            borderRadius: '5px',
            marginTop: '10px',
        }}>
            <Row>
                {props.users.map((userName, index) => (
                    <Col key={index} lg={4} md={6} sm={12} className="mb-3">
                        <User name={userName} sentEnableUser={props.sentEnableUser} />
                    </Col>
                ))}
            </Row>
        </Container>
    )
}

export default Team;

