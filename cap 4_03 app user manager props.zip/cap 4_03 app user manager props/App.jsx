import React, {useState} from 'react'
import './app.css';
import Display from './components/Display'
import Team from './components/Team'

function App() {
    const [userName, setUserName] = useState("no user")

    function enableUser(anUserName) {
        setUserName(anUserName)
    }

    return(
        <div>
            <Display message={"Usuário ativo: " + userName} />
            <Team users={["Alice", "Manoel"]} sentFunction={enableUser} />
        </div>
    )
}
export default App