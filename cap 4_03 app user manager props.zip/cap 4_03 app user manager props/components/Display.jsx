import React from 'react'

function Display(props) {
    return(
    <div className='display'>
        <h3>{props.message}</h3>
    </div>
  )
}
export default Display