import React from 'react'
function Body() {
  return(
    <div>
        <p>Corpo</p>
    </div>
  )
}
export default Body
