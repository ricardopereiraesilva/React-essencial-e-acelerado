import React from 'react'
function Footer() {
  return(
    <div>
        <p>notas</p>
    </div>
  )
}
export default Footer