import React, {useState} from 'react'
import axios from "axios"

function App() {
  const [gameMessage, setGameMessage] = useState(() => {return "Carregando..."})
  const [gameMatrix, setGameMatrix] = useState(() => {return [[0, 1, 0], [1, 2, 1], [0, 1, 0]]})
  const url = "https://dogserver.pythonanywhere.com/1234"
  axios.get(url)
        .then(response => {
          const gameState = response.data;
          setGameMessage(gameState[0])
          setGameMatrix(gameState[1][0])
      })

  return(
    <div>
      <h1>Exemplo requisições HTTP - GET</h1>
      <h2>Mensagem: {gameMessage}</h2>
      <h2>Matriz:</h2>
      <h2>{gameMatrix[0][0]} {gameMatrix[0][1]} {gameMatrix[0][2]}</h2>
      <h2>{gameMatrix[1][0]} {gameMatrix[1][1]} {gameMatrix[1][2]}</h2>
      <h2>{gameMatrix[2][0]} {gameMatrix[2][1]} {gameMatrix[2][2]}</h2>
      </div>

  )
}
export default App
